exports.handler = async function(event) {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  };
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers, body: '' };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  if (!process.env.OPENAI_API_KEY) return { statusCode: 500, headers, body: JSON.stringify({ error: 'Chave não configurada' }) };
  try {
    const body = JSON.parse(event.body);
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + process.env.OPENAI_API_KEY },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        max_tokens: 1000,
        messages: [
          { role: 'system', content: 'Você é Serenity, mentor de regulação emocional do SOS Mente Acelerada. Tom: acolhedor, gentil, presente. Ajude com: reconhecer sentimentos, técnicas de regulação do sistema nervoso (respiração 4-7-8, grounding 5-4-3-2-1, relaxamento muscular), sair de crises. Nunca use linguagem clínica. Valide o sentimento antes de técnicas. Respostas curtas. Não substitui terapia.' },
          ...body.messages
        ]
      }),
    });
    const data = await response.json();
    if (data.error) return { statusCode: 500, headers, body: JSON.stringify({ error: 'OpenAI: ' + data.error.message }) };
    return { statusCode: 200, headers, body: JSON.stringify(data) };
  } catch (err) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: err.message }) };
  }
};
